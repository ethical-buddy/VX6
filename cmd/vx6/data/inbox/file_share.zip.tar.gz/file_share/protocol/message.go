package protocol

import (
	"encoding/json"
	
	"net"
)
type AnnounceMessage struct {
	Type   string   `json:"type"`
	PeerID string   `json:"peer_id"`
	IPv6   string   `json:"ipv6"`
	Port   int      `json:"port"`
	Role   string   `json:"role"`
	Files  []string `json:"files"`
}
func Send(conn net.Conn, msg AnnounceMessage) error {
	return json.NewEncoder(conn).Encode(msg)}
func Receive(conn net.Conn) (AnnounceMessage, error) {
	var msg AnnounceMessage
	err := json.NewDecoder(conn).Decode(&msg)
	return msg, err
}